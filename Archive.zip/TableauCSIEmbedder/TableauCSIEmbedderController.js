({
    doInit: function(component, event, helper) {
        console.log('TableauCSI Embedder initializing...');
        helper.initializeComponent(component);
    },
    
    openInCurrentTab: function(component, event, helper) {
        console.log('Opening in current tab...');
        helper.navigateToPage(component, false);
    },
    
    openInNewTab: function(component, event, helper) {
        console.log('Opening in new tab...');
        helper.openInNewWindow(component, '_blank');
    },
    
    openInSubtab: function(component, event, helper) {
        console.log('Opening in subtab...');
        helper.openInSubtab(component);
    },
    
    refreshEmbedder: function(component, event, helper) {
        console.log('Refreshing embedder...');
        component.set("v.isLoading", true);
        component.set("v.hasError", false);
        
        // Refresh the iframe
        var iframe = component.find("lightningPageFrame");
        if (iframe) {
            var iframeElement = iframe.getElement();
            if (iframeElement) {
                iframeElement.src = iframeElement.src; // Force reload
            }
        }
        
        // Simulate refresh
        setTimeout(function() {
            helper.generatePageUrl(component);
            component.set("v.isLoading", false);
            helper.showToast(component, 'Success', 'Embedder refreshed', 'success');
        }, 1000);
    },
    
    onIframeLoad: function(component, event, helper) {
        console.log('Lightning page iframe loaded successfully');
        var iframe = event.getSource().getElement();
        
        try {
            // Check if iframe loaded successfully (not blocked)
            var iframeDocument = iframe.contentDocument || iframe.contentWindow.document;
            
            // If we can access the document, it loaded successfully
            if (iframeDocument) {
                console.log('Iframe content accessible');
                helper.showToast(component, 'Success', 'Dashboard loaded successfully', 'success');
            }
        } catch (error) {
            // Cross-origin restriction - likely blocked by CSP
            console.log('Iframe content restricted (likely CSP):', error);
            helper.showIframeFallback(component);
        }
    },
    
    onIframeError: function(component, event, helper) {
        console.error('Lightning page iframe failed to load');
        helper.showIframeFallback(component);
        helper.showToast(component, 'Warning', 'Direct embedding blocked, showing navigation options', 'warning');
    }
})