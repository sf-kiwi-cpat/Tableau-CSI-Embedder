({
    initializeComponent: function(component) {
        console.log('Initializing TableauCSI Embedder component');
        
        // Set initial loading state
        component.set("v.isLoading", true);
        component.set("v.hasError", false);
        
        // Generate page URL
        this.generatePageUrl(component);
        
        // Check for auto-navigate
        var autoNavigate = component.get("v.autoNavigate");
        if (autoNavigate) {
            setTimeout(function() {
                this.navigateToPage(component, false);
            }.bind(this), 1000);
        } else {
            // Just stop loading after initialization
            setTimeout(function() {
                component.set("v.isLoading", false);
            }, 500);
        }
    },
    
    generatePageUrl: function(component) {
        try {
            var pageName = component.get("v.pageName");
            var recordId = component.get("v.recordId");
            var variant = component.get("v.variant");
            
            // Build Lightning URL
            var baseUrl = this.getLightningDomain();
            var url = baseUrl + '/lightning/page/' + pageName;
            
            // Add parameters
            var params = [];
            if (recordId) {
                params.push('recordId=' + encodeURIComponent(recordId));
            }
            if (variant) {
                params.push('variant=' + encodeURIComponent(variant));
            }
            
            if (params.length > 0) {
                url += '?' + params.join('&');
            }
            
            component.set("v.lightningPageUrl", url);
            console.log('Generated Lightning page URL:', url);
            
        } catch (error) {
            console.error('Error generating URL:', error);
            this.handleError(component, 'Failed to generate page URL: ' + error.message);
        }
    },
    
    getLightningDomain: function() {
        // Get the Lightning domain from current location
        var currentHost = window.location.hostname;
        var currentOrigin = window.location.origin;
        
        // Handle different domain patterns
        if (currentHost.includes('.vf.force.com')) {
            // VF domain: orgname--c.vf.force.com -> orgname.lightning.force.com
            var orgName = currentHost.split('--')[0];
            return 'https://' + orgName + '.lightning.force.com';
        } else if (currentHost.includes('.vf.')) {
            // Custom VF domain
            return currentOrigin.replace('.vf.', '.lightning.');
        } else if (currentHost.includes('.lightning.')) {
            // Already Lightning domain
            return currentOrigin;
        } else {
            // Default/fallback
            return currentOrigin.replace(/^https?:\/\/[^.]+/, 'https://lightning');
        }
    },
    
    navigateToPage: function(component, replace) {
        try {
            var pageName = component.get("v.pageName");
            var recordId = component.get("v.recordId");
            var variant = component.get("v.variant");
            
            // Use Lightning Navigation Service
            var navService = component.find("navService");
            if (navService) {
                var pageReference = {
                    type: 'standard__namedPage',
                    attributes: {
                        pageName: pageName
                    },
                    state: {}
                };
                
                if (recordId) {
                    pageReference.state.recordId = recordId;
                }
                if (variant) {
                    pageReference.state.variant = variant;
                }
                
                navService.navigate(pageReference, replace);
            } else {
                // Fallback to URL navigation
                var url = component.get("v.lightningPageUrl");
                if (url) {
                    window.location.href = url;
                } else {
                    this.handleError(component, 'Navigation URL not available');
                }
            }
            
        } catch (error) {
            console.error('Navigation error:', error);
            this.handleError(component, 'Navigation failed: ' + error.message);
        }
    },
    
    openInNewWindow: function(component, target) {
        var url = component.get("v.lightningPageUrl");
        if (url) {
            window.open(url, target);
        } else {
            this.showToast(component, 'Error', 'Page URL not available', 'error');
        }
    },
    
    openInSubtab: function(component) {
        try {
            // Try to use workspace API for omni-channel
            if (typeof sforce !== 'undefined' && sforce.console && sforce.console.isInConsole()) {
                var url = component.get("v.lightningPageUrl");
                var tabLabel = component.get("v.title") || 'Tableau CSI';
                
                sforce.console.openSubtab(null, url, true, tabLabel, null, function(result) {
                    if (result.success) {
                        console.log('Subtab opened successfully:', result.id);
                    } else {
                        console.log('Failed to open subtab, falling back to navigation');
                        this.navigateToPage(component, false);
                    }
                }.bind(this));
            } else {
                // Fallback to regular navigation
                console.log('Not in console, using regular navigation');
                this.navigateToPage(component, false);
            }
        } catch (error) {
            console.error('Subtab error:', error);
            // Fallback to regular navigation
            this.navigateToPage(component, false);
        }
    },
    
    handleError: function(component, message) {
        component.set("v.hasError", true);
        component.set("v.errorMessage", message);
        component.set("v.isLoading", false);
        this.showToast(component, 'Error', message, 'error');
    },
    
    showIframeFallback: function(component) {
        console.log('Showing iframe fallback navigation');
        
        // Hide the iframe and show fallback navigation
        var embeddedPage = component.find("lightningPageFrame");
        var fallbackNav = component.find("fallbackNavigation");
        
        if (embeddedPage) {
            $A.util.addClass(embeddedPage.getElement().parentNode, "slds-hide");
        }
        
        if (fallbackNav) {
            $A.util.removeClass(fallbackNav, "slds-hide");
        }
    },
    
    showToast: function(component, title, message, variant) {
        try {
            var toastEvent = $A.get("e.force:showToast");
            if (toastEvent) {
                toastEvent.setParams({
                    title: title,
                    message: message,
                    type: variant,
                    duration: 3000
                });
                toastEvent.fire();
            } else {
                // Fallback for environments without toast
                console.log('Toast: ' + title + ' - ' + message);
                if (variant === 'error') {
                    alert('Error: ' + message);
                }
            }
        } catch (error) {
            console.error('Toast error:', error);
        }
    }
})